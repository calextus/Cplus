#include <iostream>

using namespace std;

int main()
{
    double Area, Radius, Pi = 3.14;

    //Input...
    cout << "Enter the radius: " <<endl;
    cin >> Radius;

    //processing...
    Area = Radius * Radius * Pi;

    //output...
    cout << " this is the Area of the circle: " <<Area <<endl;


    return 0;
}
