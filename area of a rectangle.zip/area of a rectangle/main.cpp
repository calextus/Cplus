#include <iostream>

using namespace std;

int main()
{

    double Length, Width, Area, Perimeter;

    cout << "Question 3, find the area of the rectangle" <<endl;

    //the questioner
    cout << "Enter the Length: " <<endl;
    cin >> Length;

    cout << "Enter the Width: " <<endl;
    cin >> Width;

    // the calculation...
    Area = Length * Width;

    //the output...
    cout << "This is the area of the rectangle:  " <<Area <<endl;

    //perimeter calculation...
    Perimeter = 2 * (Length + Width) ;
    //the output...
    cout << "This is the perimeter of the rectangle: " <<Perimeter <<endl;


    return 0;
}
