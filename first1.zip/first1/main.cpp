#include <iostream>

using namespace std;

int main()
{
    //declare numbers as variables
    double num1, num2, sum;

    //the questioner
    cout << "Enter First Number" << endl;
    cin >>num1;

    cout << "Enter Second number" <<endl;
    cin >>num2;

    //the calculation
     sum = num1 + num2;

    //the result
    cout << "This is the result of two added numbers = "<<sum <<endl;
    return 0;
}
