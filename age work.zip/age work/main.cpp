#include <iostream>

using namespace std;

int main()
{
    //Variable declaration
    int Age;

    cout << "Please enter your age" <<endl;
    cin >> Age;

    //Decission....
    if (Age < 18) {

    cout << "Your age is : " <<Age << "You are young" <<endl;

    } else if (Age >= 18 && Age <30 ) {

    cout << "Your age is : " << Age << "You are an Adult" <<endl;

    } else {

    cout << "Your age is : " << Age << " You are old" <<endl;

    }


    return 0;
}
