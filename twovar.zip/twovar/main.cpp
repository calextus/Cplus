#include <iostream>

using namespace std;

int main()
{
    int a = 0;
    int b = 0;



    cout << "Enter the first number" <<endl;
    cin >> a;

    cout << "Enter the second number" <<endl;
    cin >> b;

    //output.....
double sum = a + b;
    cout << "the sum of the two numbers is: " <<sum <<endl;


    return 0;
}
