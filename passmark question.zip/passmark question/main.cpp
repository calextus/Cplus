#include <iostream>

using namespace std;

int main()
{
    //the declaration...
    double Marks, Passmarks = 50;

    //the Input..

    cout << "Enter the marks obtained" <<endl;
    cin >> Marks;


    //Decision....

    if (Marks > Passmarks) {

    cout << "You have passed with : " << Marks <<endl;

    } else {

    cout << " You have failed with : " <<Marks <<endl;

    }



    return 0;
}
